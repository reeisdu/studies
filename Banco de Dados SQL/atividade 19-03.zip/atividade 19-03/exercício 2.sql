-- Database: aula_Aula03b

-- DROP DATABASE IF EXISTS "aula_Aula03b";

CREATE DATABASE "aula_Aula03b"
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'Portuguese_Brazil.1252'
    LC_CTYPE = 'Portuguese_Brazil.1252'
    LOCALE_PROVIDER = 'libc'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

	--EXERCÍCIO 2


	create table aluno (
		rgm int,
		nome varchar(100),
		endereco varchar(100),
		telefone numeric(10)
	);

	create table disciplina (
		codigo int,
		nome varchar(100),
		ementa varchar(100)
	);

	create table aluno_disciplina (
		cod_aluno int,
		cod_disciplina int,
		nota1 numeric(2,2),
		nota2 numeric(2,2),
		media numeric(2,2),
		faltas numeric(2,2)
	);

	alter table aluno add constraint pk_aluno primary key (rgm);
	alter table disciplina add constraint pk_codigo primary key (codigo);
	alter table aluno_disciplina add constraint fk_cod_aluno foreign key (cod_aluno) references aluno(rgm);
	alter table aluno_disciplina add constraint fk_cod_disciplina foreign key (cod_disciplina) references aluno(rgm);

	alter table aluno add column RG numeric(15);
	alter table aluno add column CPF numeric (11);
	alter table aluno drop column faltas;
	alter table aluno_disciplina rename to NOTAS;
	alter table NOTAS alter column media set not null;
	alter table aluno rename to alunos;
	drop table disciplina;
	drop table alunos, NOTAS;
	
	
	