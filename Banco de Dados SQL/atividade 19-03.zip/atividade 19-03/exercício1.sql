-- Database: atividade 19-03

-- DROP DATABASE IF EXISTS "atividade 19-03";

CREATE DATABASE "atividade 19-03"
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'Portuguese_Brazil.1252'
    LC_CTYPE = 'Portuguese_Brazil.1252'
    LOCALE_PROVIDER = 'libc'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

	--EXERCÍCIO 1

	create table teste (
		codigo numeric(5) not null,
		salario numeric(5,2),
		dia_hoje date,
		texto varchar(10),
		aprovado boolean
	);

	alter table teste rename to AULABD;
	alter table AULABD rename column aprovado to situacao;
	alter table AULABD add column RGM numeric(5);
	alter table AULABD add column novo_campo varchar(100);
	alter table AULABD alter column novo_campo set not null;
	alter table	AULABD drop column salario;
	alter table AULABD add constraint pk_RGM primary key (RGM);
	drop table AULABD;


	
	
	



	