/**
 * 
 */
/**
 * 
 */
module ClasseObjeto {
}