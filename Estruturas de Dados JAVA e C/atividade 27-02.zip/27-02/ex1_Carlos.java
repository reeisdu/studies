//Exercício das Taxas

import java.util.Scanner;

public class ex1_Carlos {
    public static void main(String[] args) {
        Scanner x = new Scanner(System.in);

        double salario, objetivo, valorAtual;
        int meses = 0;

        System.out.println("Digite o salário de João: ");
        salario = x.nextDouble();

        System.out.println("Digite o valor que deseja alcançar: ");
        objetivo = x.nextDouble();

        valorAtual = salario;

        while (valorAtual <= objetivo) {
            valorAtual = valorAtual + (valorAtual * 0.02);
            meses++;
        }

        System.out.println("Valor Final: " + valorAtual);
        System.out.println("Meses necessáiros: " + meses);

        x.close();
    }
}
