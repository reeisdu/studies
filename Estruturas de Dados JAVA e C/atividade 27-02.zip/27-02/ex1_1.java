//Primeios Exercícios

import java.util.Scanner;

public class ex1_1 {
    public static void main(String[] args) {
        Scanner x = new Scanner(System.in);
        
        double n;
        double soma = 0;
        int qtd = 0;

        double maior = Double.MIN_VALUE;
        double menor = Double.MAX_VALUE;

        double somaPares = 0;
        int qtdPares = 0;

        System.out.println("Digite notas entre 10 e 20: ");
        System.out.println("Digite um valor inválido para encerrar: ");

        while (true) {
            System.out.println("Digite uma nota: ");
            n = x.nextDouble();
            
            if (n < 10 || n > 20) {
                break;
            }           

            soma += n;
            qtd++;

            if (n > maior) {
                maior = n;
            }

            if (n < menor) {
                menor = n;
            }

            if (n % 2 == 0) {
                somaPares += n;
                qtdPares++;
            }
        }
        if (qtd > 0) {
            double media = soma / qtd;
        

        System.out.println("====== RESULTADOS ======");
        System.out.println("Soma dos númeoros: " + soma);
        System.out.println("Quantidade dos dados fornecidos: " + qtd);
        System.out.println("Média Geral: " + media);
        System.out.println("Maior número: " + maior);
        System.out.println("Menor número: " + menor);
        }
        
        if (qtdPares > 0) {
            double mediaPares = somaPares / qtdPares;
            System.out.println("Média dos números Pares: " + mediaPares);    
        } else {
            System.out.println("Nenhum número par foi digitado.");
        }

    x.close();

    }
}
